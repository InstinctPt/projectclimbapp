package leandro.ipca.projectclimb.models

import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.util.*

data class Event(
    var id: Int,
    var title: String,
    var description: String,
    ){

    fun toHashMap() : HashMap<String,Any> {
       return hashMapOf(
           "id" to id,
            "title"    to title,
            "description"   to description,
        )
    }

    companion object {

        fun fromDoc( documentSnapshot: DocumentSnapshot) : Event{
            return Event(
                documentSnapshot.getLong("id")!!.toInt(),
                documentSnapshot.getString("title")!!,
                documentSnapshot.getString("desc")!!,
            )
        }
    }

    fun sendPost(callback: (error:String?)->Unit) {
        val db = Firebase.firestore
        db.collection("posts")
            .add(toHashMap())
            .addOnSuccessListener { documentReference ->
                callback(null)
            }
            .addOnFailureListener { e ->
                callback(e.toString())
            }
    }

    fun getEvent(callback: (error:String?)->Event) {
        val db = Firebase.firestore
        db.collection("posts")
            .add(toHashMap())
            .addOnSuccessListener { documentReference ->
                callback(null)
            }
            .addOnFailureListener { e ->
                callback(e.toString())
            }
    }


}
